<?php
$id=$_GET['id'];
$conn=new mysqli("localhost","root"," ","ogs");
$qry="delete from ordr where id=$id";
$res=$conn->query($qry);
header("location:fetchorder.php");
?>