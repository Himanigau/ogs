<?php 
if(isset($_GET['price']))
{

	$url=$_SERVER['REQUEST_URI'];
	$url_components=parse_url($url);
	parse_str($url_components['query'],$params);
	$price=$params['price'];
}
?>




<?php
if(isset($_POST['ord']))
{    echo "hello";
    
    
  
	$conn=new mysqli("localhost","root","","ogs");
	
	$qry="insert into ordr(cname,address,price1,qnty,total)values('$cname','$address','$price1','$qnty','$total')";
	$res=$conn->query($qry);
	if($res){
		echo "Order success";
		}
}
?>


<!--<?php
session_start();
if(isset($_SESSION['username']))
{
?>
	<h1>Hello <?php echo$_SESSION["username"];?> </h1> 
	
	<?php
}
?>-->
<!DOCTYPE html>
<html>
<head> 
	<title></title>
</head>
<body> 
<center><table cellpadding="2" width="20%" bgcolor=""
cellspacing="2">
<tr>
<td colspan=2>
<center><font size=4><h2>Order Form</h2></td>
</tr>
<tr>
			<td>Customer name</td> 
                    <td>     <input type="text" name="cname" value="" >
                    </td> 
                   </tr>
                   <br>
                   <tr>
                   <td>Address</td> 
                   <td><input type="text" name="address" value="" >
                   </td>
               </tr>
               <br>
               <tr> 
			<td>Price</td>
			
			<td><input type="text" name="price1" value="<?php echo (isset($price))?$price:'';?>" maxlength="6" required><input type="hidden" class="iprice" value="<?php echo (isset($price))?$price:'';?>" maxlength="6" required>
			</td>
		</tr>
		<br> 
		<tr>
			<td>Quantity</td>
			<td><input class="iquantity" onChange='subTotal()' type="number" name="qnty" value="<?php echo (isset($qnty))?$qnty:'';?>"required></td>
		</tr> 
		<br>
		<!--<tr>
			<td>
			<input type="button" onClick='Add()' name="ad" value="Add"><br>
			</td>
		</tr>--> 
		<br>
		<tr>
			<td>Total</td> 
			<td class="itotal"><input type="text"  name="total" value="" required>
		</tr> 
		<tr>
			<td><input type="submit" name="ord" value="Order"></td>
		</tr
		</table> 
</center>
	<script>
		var iprice=document.getElementsByClassName('iprice');
		var iquantity=document.getElementsByClassName('iquantity');
		var itotal=document.getElementsByClassName('itotal');
		function Add()
		{
			header("location:ogs.php");
   		
		}
		function subTotal()
		{
			for(i=0;i<iprice.length;i++)
			{
				itotal[i].innerText=(iprice[i].value)*(iquantity[i].value);
			}
		}
		subTotal();
	</script> 
</body>
</html>