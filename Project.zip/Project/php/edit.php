<?php
$id=$_GET['id'];
$conn=new mysqli("localhost","root","","ogs");
$qry="select *from prod where id=$id";
$res=$conn->query($qry);
$row=$res->fetch_assoc();
print_r($row);
?>

<html>
<head>
       <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">                      

	</head> 
	<body>
		<div class="card">
		<div class="card-header">
			<h2>AddProduct</h2>
				<div class="block">
					<form method="post" action="fetch1.php" enctype="multipart/form-data">
						<div class="card-body">
							<input type="hidden" name="id" value="<?php echo $row['id'];?>">
						<div class="form=group">
							<label for="Categories" class="form-control-label">Categories</label>
							<!--<select class="form-control" name="categories_id">
							<option value="Category 1"<?php if($row['Categories']=='Category 1') echo "selected"; ?> >Category 1 </option>
							<option value="Category 2" <?php if($row['Categories']=='Category 2') echo "selected"; ?>>Category 2</option>
							<option value="Category 3" <?php if($row['Categories']=='Category 3') echo "selected"; ?>>Category 3</option>
							<option value="Category 4" <?php if($row['Categories']=='Category 4') echo "selected"; ?>>Category 4</option>
						    </select>
						</div>-->
						<input type="number" name="categories_id"  value="<?php echo $row['categories_id'];?>"placeholder="Enter categories_id" class="form-control">
						</div>
					
							<div class="form=group">
						<label for="Product" class="form-control-label">Product</label>
                        <input type="text" name="name" value="<?php echo $row['name'];?>"  placeholder="Enter product name" class="form-control">
                    </div>
                    <div class="form=group">
						<label for="Price" class="form-control-label">Price</label>
                        <input type="number" name="price"  value="<?php echo $row['price'];?>"placeholder="Enter price" class="form-control">
                    </div>                    
                    <div class="form=group">
						<label for="Image" class="form-control-label">Image</label>
                        <input type="file" name="image"  value="<?php echo $row['image'];?>"class="form-control">
                    </div>                    
		             <div colspan="2" align="center"><input type="button" name="submit" value="upload" class="btn btn-success"> </div> 
		         </div> 
		     </form> 
		 </div> 
		</div> 
	</div> 
</body> 
</html> 