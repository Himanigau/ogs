<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<title></title>
</head>
<body>
	<div class="parallax">
		<div class="page-title">Packed Foods</div> 
	</div> 
	<div class="container">
		<a href="cookies.php">
			<div class="categories">
				<img src="images/44.png" width=30% height=30% class="item-image"/>
				<div class="image-title">Cookies & Biscuits</div> 
			</div> 
		</a> 
	
		<a href="chocolate.php">
			<div class="categories">
				<img src="images/43.png" width=30% height=30% class="item-image"/>
				<div class="image-title">Chocolates</div> 
			</div> 
		</a> 
		<a href="snacks.php">
			<div class="categories">
				<img src="images/135.png" width=30% height=30% class="item-image"/>
				<div class="image-title">Snacks & Chips</div> 
			</div> 
		</a> 
		<a href="noodle.php">
			<div class="categories">
				<img src="images/11.png" width=30% height=30% class="item-image"/>
				<div class="image-title">Noodles & Pasta</div> 
			</div> 
		</a> 
	</div> 
</body> 
</html>