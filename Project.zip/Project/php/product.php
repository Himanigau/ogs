<html>
<head>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
</head> 
<body>
	<div class="animated fadeIn">
		<div class="container-fluid">
			<div class="row">
				<div class="col=lg-6">

	<div class="card">
		<div class="card-header">
			<h2>AddProduct</h2>
				<div class="block">
					<form method="POST" action="product.php" enctype="multipart/form-data">
						<div class="card-body">
						<div class="form-group">
							<label for="Categories_id" class="form-control-label">Categories</label>
						    <input type="number" name="categories_id" placeholder="Enter categories_id" pattern="[0-9]" class="form-control">
						</div>
					
							<div class="form-group">
						<label for="Product" class="form-control-label">Product</label>
                        <input type="text" name="name" placeholder="Enter product name" class="form-control">
                    </div>
                    <div class="form-group">
						<label for="Price" class="form-control-label">Price</label>
                        <input type="number" name="price" placeholder="Enter price" pattern="[0-9]" class="form-control">
                    </div>
                    <div class="form-group">
						<label for="Image" class="form-control-label">Image</label>
                        <input type="file" name="image" class="form-control">
                    </div>
						 <br>  
			               <div colspan="2" align="center"><input type="submit" name="submit" value="upload" class="btn btn-success"> </div></div> 
				</div>  
			</form>
			</div>
		</div> 
	</div>
	</div> 
</div>
</div> 
</div> 
</body> 
</html>


<?php
 if(isset($_POST['submit'])){
	print_r($_POST);
	extract($_POST);

     $f=$_FILES['image']['name'];
     $ft=$_FILES['image']['type'];
     $fs=$_FILES['image']['size'];
     print_r($f);
	 $dst="uploadimg/".$f;
     if (move_uploaded_file($_FILES['image']["tmp_name"],$dst))
     {
     	echo "Files are uploaded.";
     }
	$conn=new mysqli("localhost","root","","ogs");
	$qry="INSERT INTO `prod`(`id`, `categories_id`, `name`, `price`, `image`) VALUES (NULL,'$categories_id','$name','$price','$dst')";
	$res=$conn->query($qry);
	if($res)
	{
		echo "Data Saved.";
	}
	else
	{
		echo "Data not Saved";
	}
}
?>