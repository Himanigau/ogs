<?php
session_start();
$conn=new mysqli("localhost","root","","ogs");
if(isset($_POST['email']))
{
$username=$_POST['email'];
$password=$_POST['password'];
$s="select * from register where username='$username' and password='$password'";
$res=$conn->query($s);
{
	echo "Customer already exist";
}
}
else{
	echo "Invalid username and password";
}
?>