<?php
$id=$_GET['id'];
$conn=new mysqli("localhost","root","","ogs");
$qry="select *from category where id=$id";
$res=$conn->query($qry);
$row=$res->fetch_assoc();
print_r($row);
?>

<!DOCTYPE html>
<head><link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
</head>
<body>
	<div class="content pb-0">

	<div class="animated fadeIn">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
				<div class="card-header"><strong>Categories</strong><small>Form</small></div>
				<form method="POST" action="fech.php">
					<div class="card-body card-block">
						<div class="form-group">
					<label for="categories" class="form-control-label">Categories</label>
					<input type="text" name="categories" placeholder="Enter categories name" class="form-control" value="<?php echo $row['categories'];?>">
					
				</div>
				<button  name="submit" type="submit" class="btn btn-lg btn-success btn-block">
					<span >Submit</span>
					</button>
				</div> 
			</form> 
		</div>
	</div>
	</div> 
</div>
</div>
</div>
</body>

