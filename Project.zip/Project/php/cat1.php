<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<title></title>
</head>
<body>
	<div class="parallax">
		<div class="page-title">Food Grains & Staples</div> 
	</div> 
	<div class="container">
		<a href="prod1.php">
			<div class="categories">
				<img src="images/14.png" width=30% height=30% class="item-image"/>
				<div class="image-title">Atta and Flours</div> 
			</div> 
		</a> 
	
		<a href="pulses.php">
			<div class="categories">
				<img src="images/dals-pulses-20200714.png" width=30% height=30% class="item-image"/>
				<div class="image-title">Pulses</div> 
			</div> 
		</a> 
		<a href="spices.php">
			<div class="categories">
				<img src="images/15.png" width=30% height=30% class="item-image"/>
				<div class="image-title">Spices</div> 
			</div> 
		</a> 
		</div>
</body>
</html>