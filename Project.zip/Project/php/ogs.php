<html>
<head>
	<title> Online Grocery Store </title> 
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<table border="0" width="100%"  height="8%" bgcolor="#CC0033" >
		<tr>
			<td align="center"  	width="70%"><font color="#0033cc"  size="100px" > <b> Online Grocery Store</font></b></td>
			<td><th align="right" ><font color="#0033cc"><a href=" l.php">Login</a> </font></th>
				<th align="center" width="17%"><font color="#0033cc"><a href=" dashboard.php">Logout</a></font></th>
			</td>
		</tr> 
	</table>
	<div class="navbar">
    	<ul>
			<li> <a href=" #">Home</a></li>
			<li> <a href=" ">Category</a>
		        <ul>
		            <li><a href="Prod1.php">Food Grains</a> </li>
		    		<li><a href="cookies.php">Packed Foods</a> </li>
		            <li><a href="hair.php">Personal Care</a> </li>
		            <li><a href="detergents.php">Household Items</a> </li>
		    	</ul>
			</li>
			<li> <a href="cookies.php ">Product</a></li>
			<li> <a href="contactinsert.php ">Contact Us</a></li>
			<li> <a href=" about.php">About Us</a></li>
			<li> <a href=" l.php">Login</a></li>
		</ul>
	</div>    
	<br>
	<br>
	<div class="slide-container">
		<div class="image-container  fade">
			<img src=" images/a2.png"  width="100%" height="200px"></div>
		<div class="image-container fade">
			<img src="images/mall1.jpeg"  width="100%"  height="200px"></div>
		<div class="image-container fade">
			<img src="images/a1.jpg"   width="100%"  height="200px"></div>
	</div> 
	<h2><a href="new.php">New Arrivals</a></h2>
    <div class="container">
		<div class="row">
       		<?php
       			$qry="select * from prod where id between 59 and 100";
       			$conn=new mysqli("localhost","root","","ogs");
       			$res=$conn->query($qry);
      			$check=mysqli_num_rows($res)>0;
       			if($check)
       			{
       				while($row=$res->fetch_assoc())
       				{
      	    ?>
            <div class="col-md-3">
				<div class="card">
				    <div class="product-content">
                	<div class="product-img">
						<img class="card-img-top" src=<?php echo $row['image'];?>  alt="" height="250px" width="250px"> 
				</div> 
			</div> 
			<h4 class="product-name"><?php echo $row['name'];?></h4> 
			<h4 class="card-title"><?php echo "Price:".$row['price'];?></h4> 				
			<button type="button" class="btn btn-success" name="buy"><a href="odr.php?price=<?php echo $row['price']?> ">BUY</a> </button>
		</div>
	</div>       
	 		<?php
        		    }
            	}
        	?>
   		</div> 
 	</div> 
	<br>
	<br>
	<br>
	<div class="footer">
		<div class="container">
			<div class="rw">
				<div class="footer-col-1">
					<h3>Top Products</h3>
            		<ul>
            			<li>Chocolates</li>
            			<li>Sanitizers</li>
            			<li>Tea</li>
            		</ul>				
				<div class="footer-col-2">
            		<h3>Contacts</h3>
            		<ul>
            			<li>New Delhi,Avenue Street 10</li>
            			<li>042876836908</li>
            			<li>company@gmail.com</li>
            			<li>24/7</li>
            		</ul>
            	</div>
            	<div class="footer-col-3">
            		<p>Thank you for visiting our website</p>
				</div>	
        		</div>
    		</div>
		</div>
	</div>
	<script>
		var myIndex=0;
		carousel();
		function carousel()
		{
		var i;
		var x=document.getElementsByClassName("image-container");
		for(i=0;i<x.length;i++)
		{
		x[i].style.display="none";
		}
		myIndex++;
		if(myIndex>x.length)
		{myIndex=1}
		x[myIndex-1].style.display="block";
		setTimeout(carousel,3000);
		} 
	</script>
	<br>
</body> 
</html>