<?php
if(isset($_POST['submit']))
{
	print_r($_POST);
	extract($_POST);
	echo "Categories is:".$categories;
    $conn=new mysqli("localhost" ,"root" ,"","ogs");
    $qry="INSERT INTO `category`(`id`, `categories`, `status`) VALUES (NULL,'$categories',1)";
    $res=$conn->query($qry);
    if($res)
    {
    echo "Data saved";
    }
    else{
    	echo "Data not Saved,";
    }
}
?>

<!DOCTYPE html>
<head><link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
</head>
<body>
	<div class="content pb-0">

	<div class="animated fadeIn">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
				<div class="card-header"><strong>Categories</strong><small>Form</small></div>
				<form method="POST" action="cat.php">
					<div class="card-body card-block">
						<div class="form-group">
					<label for="categories" class="form-control-label">Categories</label>
					<input type="text" name="categories" placeholder="Enter categories name" pattern="[a-zA-Z0-9}" class="form-control">
					
				</div>
				<button type="submit" name="submit"  class="btn btn-lg btn-success btn-block">
					<span >Submit</span>
					</button>
				</div> 
			</form> 
		</div>
	</div>
	</div> 
</div>
</div>
</div>
</body>
</html>

