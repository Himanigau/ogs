<?php 
$conn=new mysqli("localhost","root" ,"","ogs");
$qry="select * from contact_us order by id desc";
$res=$conn->query($qry);
?>
<html>
<head>
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="container-fluid">
		<div class='row'>
			<div class="col-md-12">
			<div class="card">
				<div class="card-body">
					<h4 class="box-title">Contact Us</h4>
				</div>
				<div class="card-body">
					<div class="table-stats order-table ov-h">
						<table class="table">
							<thead>
								<tr>
									
									<th>Id</th>
								    <th>Name</th>
								    <th>Email</th>
								    <th>Mobile</th>
								    <th>Comment</th>
								    <th>addedon</th>
								    <th>Action</th>
									
								</tr>
							</thead>
							<?php
						
							while($row=$res->fetch_assoc())
						{
							?>
							<tr>
								<td><?php echo $row['id']?></td>
								<td><?php echo $row['username']?></td>
								<td><?php echo $row['email']?></td>
								<td><?php echo $row['mobile']?></td>
								<td><?php echo $row['comment']?></td>
							    <td><?php echo $row['addedon']?></td>
					            	<td><span class="badge-delete"><a href="delcontact.php?id=<?php echo $row['id'];?>">Delete</a></span> </td>
					            	
								</tr>
							<?php

						}
						?>

						</table>
						
				</div>
			</div>
		</div>
	</div>
</div>

</body>
</html>
