<?php
if(isset($_POST['submit']))
{
	extract($_POST);
	$conn=new mysqli("localhost","root","","ogs");
    $qry="insert into contact_us(username,email,mobile,comment)values('$username','$email','$mobile','$comment')";
    $res=$conn->query($qry);
    echo $qry;
    if($res)
    {
    	echo "Satisfied";
    }
    else
    {
    	echo "Unsuccessfull";
    }
}
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<title></title>
</head>
<body>
<div class="content pb-0">

	<div class="animated fadeIn">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-6">
				<div class="card">
				<div class="card-header"><strong>Contact</strong><small>Form</small></div>
				<form method="POST" action="contactinsert.php">
					<div class="card-body card-block">
						<div class="form-group">
					<label for="Name" class="form-control-label">Name</label>
					<input type="text" name="username" placeholder="Enter name" pattern="[a-zA-Z]{3,}" class="form-control">
					
				</div>
				<div class="form-group">
					<label for="Email" class="form-control-label">Email</label>
					<input type="text" name="email" placeholder="Enter email" pattern="[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$" class="form-control">
					
				</div>
				<div class="form-group">
					<label for="mobile" class="form-control-label">Mobile</label>
					<input type="text" name="mobile" placeholder="Enter mobile number" pattern="[6-9]{1}[0-9]{9}" class="form-control">
					
				</div>
				<div class="form-group">
					<label for="Comment" class="form-control-label">Comment</label>
					<textarea name="comment" placeholder="Write comment Here" pattern="[a-zA-Z0-9]{1,}"class="form-control">
					</textarea>
				</div>
				<button  name="submit" type="submit" class="btn btn-lg btn-success btn-block">
					<span >Send</span>
					</button>
				</div> 
			</form> 
		</div>
	</div>
	</div> 
</div>
</div>
</div>
</body>
</html>