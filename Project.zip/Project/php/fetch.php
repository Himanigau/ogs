<?php 
$conn=new mysqli("localhost" ,"root" ,"","ogs");
$qry="select * from adminusers";
$res=$conn->query($qry);
?>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
</head>
<body>
		<div class="row">
			<div class="col-md-12">
			<div class="card">
				<div class="card-body--">
					<h4 class="box-title">Categories</h4>
				</div>
				<div class="card-body">
					<div class="table-stats order-table ov-h">
						<table class="table">
							<thead>
								<tr>
									
									<th>Id</th>
								    <th>Username</th>
								    <th>password</th>
									
								</tr>
							</thead>
							<?php
							
							while($row=$res->fetch_assoc())
						{
							?>
							<tr>
								
								
								<td><?php echo $row['id']?></td>
								<td><?php echo $row['username']?></td>
								<td><?php echo $row['password']?></td>
							    <td>
                                </td>
					            <td><span class='btn btn-danger'><a href="del.php?id=<?php echo $row['id'];?>">Delete</a></span></td>
								</tr>
								<?php
						}
						?>
						</table>						
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>