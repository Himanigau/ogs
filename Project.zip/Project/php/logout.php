<?php
session_start();
session_unset($SESSION);
header("location:l.php");
?>