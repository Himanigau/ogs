<?php
$id=$_GET['id'];
$conn=new mysqli("localhost","root"," ","ogs");
$qry="delete from contact_us where id=$id";
$res=$conn->query($qry);
header("location:contact.php");
?>