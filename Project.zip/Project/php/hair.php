<?php
include('cat3.php');
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<title></title>
</head>
<body>
<div class="container">
	<div class="row">
       	<?php
       		$qry="select * from prod where id between 36 and 40";
       		$conn=new mysqli("localhost","root","","ogs");
       		$res=$conn->query($qry);
      		$check=mysqli_num_rows($res)>0;
       		if($check)
       		{
       			while($row=$res->fetch_assoc())
       				{
      	    ?>
            <div class="col-md-3">			    	
				   <div class="card">
				    <div class="product-content">
                	<div class="product-img">
						<img class="card-img-top" src=<?php echo $row['image'];?>  alt="" height="250px" width="250px"> 
					</div> 
					</div> 
					<h4 class="product-name"><?php echo $row['name'];?></h4> 
					<h4 class="card-title"><?php echo "Price:".$row['price'];?></h4> 					
					<button type="button" class="btn btn-success" name="buy"><a href="odr.php?price=<?php echo $row['price']?> ">BUY</a> </button>
				</div>
			</div> 		
        	<?php
                }
            }
        ?>
    </div> 
 </div> 
</body> 
</html>