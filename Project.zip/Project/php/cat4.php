<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<title></title>
</head>
<body>
	<div class="parallax">
		<div class="page-title">Household Items</div> 
	</div> 
	<div class="container">
		<a href="detergents.php">
			<div class="categories">
				<img src="images/detergents.png" width=30% height=30% class="item-image"/>
				<div class="image-title">Detergents</div> 
			</div> 
		</a> 
		<a href="cleaner.php">
			<div class="categories">
				<img src="images/7.png" width=30% height=30% class="item-image"/>
				<div class="image-title">Cleaners</div> 
			</div> 
		</a> 
	</div> 
</body> 
</html> 

		