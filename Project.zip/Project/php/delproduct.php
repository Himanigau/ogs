<?php
$id=$_GET['id'];
$conn=new mysqli("localhost","root"," ","ogs");
$qry="delete from prod where id=$id";
$res=$conn->query($qry);
header("location:fetch1.php");
?>