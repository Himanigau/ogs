<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<title></title>
	<title>About us</title>
</head>
<body class="back">
<div>
	<h1 >ABOUT US</h1> 
	<p>India's most convinient our online grocery store makes your grocery shopping even simpler.No more hassles of sweating it out in crowded markets,grocery shops & supermarkets-now shop from the comfort of your home; office or on the move.
	We offer you convinience of shopping everything that you need for your home-be it fresh fruits & vegetables,rice, dals, oil, apckaged food, dairy item, frozen, pet food, household cleaning items & personal care products from a single virtual store.
	</p>  
	<hr> 
    <div class="about">
	  	<h2 class="head">Online Grocery Shopping India</h2> 
			<p>Shop on the go and buy groceries products. We get it all delivered at your doorstep within hours. You not only save time but also money with our best prices.
			</p> 
		<h2 class="head">Single store for all your daily needs</h2>
			<p>
			Order thousands of products at just a tap;atta,pulses,spices,snacks,chips,chocolates,shampoos,handwash,cleaners,detergents and other grocery products.
			</p> 
	</div> 
</div> 
</body>
</html>