<?php
$id=$_GET['id'];
$conn=new mysqli("localhost","root"," ","ogs");
$qry="delete from category where id=$id";
$res=$conn->query($qry);
header("location:fech.php");
?>