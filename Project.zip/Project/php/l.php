<?php
session_start();
if(isset($_POST['save']))
{
				extract($_POST);
    			echo "username is:".$username;
   				 echo "password is:".$password;
    			$conn=new mysqli("localhost","root"," ","ogs"); 
 				$qry="select * from register where email='$username' and password='$password'";
    			$ress = $conn->query($qry);
 				$num=mysqli_num_rows($ress);
  				echo $num;
   				 //if($count == 1)
    			if($num==1)
    			{
   					echo "Customer Already Exists";
      				$qry1="insert into adminusers(id,username,password)values('null','$username','$password')";
      				$conn->query($qry1);
     				header("location:ogs.php");
    			}
   				else
   				{  
   					echo "Invalid Username and Password"; 
    				header("location:register.php");
   				}			
	} 
?>
<html>
  <head>
    <title>Login Form</title>
  <link rel="stylesheet" type="text/css"  href="stylee.css">
<body >
<div class="loginbox">
    <h1><b>Login Here</b></h1>
    <form action="#" method="POST">
	<input type="text" name="username" placeholder="Enter username" pattern="[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$" required>
	<input type="password" name="password" placeholder="Enter password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" required>
    <input type="submit" name="save" value="Login"><br>
	</form>
	</div>
	</body>
  </head>
</html>