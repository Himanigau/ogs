<?php
$conn=new mysqli("localhost","root","","ogs");
$qry="select * from category";
$res=$conn->query($qry);
if($res)
{
	echo "data fetches";
}
else
{
	echo "data not fetches";
}
?>
<html>
<head>
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
</head>
<body>	
		<div class="row">
			<div class="col-md-12">
				<h4 class="box-title">Categories</h4>
				<table class="table">
					<tr>									
									<th>Id</th>
								    <th>Categories</th>
								    <th>Status</th>									
					</tr>
							<?php
							while($row=$res->fetch_assoc())
						    {
							?>
					<tr>
								<td><?php echo $row['id']?></td>
								<td><?php echo $row['categories']?></td>
								<td><?php echo $row['status']?></td> 
								<td><span class='btn btn-info '><a href="delcat.php?id=<?php echo $row['id'];?>">Delete</a></span></td>
								<td><span class='btn btn-danger'><a href="editcat.php?id=<?php echo $row['id'];?>">Edit</a></span></td>
				    </tr> 
				    <?php
				    }
				    ?>
				</table> 
			</div> 
		</div> 
	</body> 
</html> 