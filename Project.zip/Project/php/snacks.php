<?php
include('cat2.php');
?>


<!DOCTYPE html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<title></title>
</head>
<body>
<div class="container">
	<div class="row">
       	<?php
       		$qry="select * from prod where id between 26 and 30";
       		$conn=new mysqli("localhost","root","","ogs");
       		$res=$conn->query($qry);
      		$check=mysqli_num_rows($res)>0;
       		if($check)
       		{
       			while($row=$res->fetch_assoc())
       				{
      	    ?>
            <div class="col-md-3">
			    
			    	
				   <div class="card">
				    <div class="product-content">
                	<div class="product-img">
						<img class="card-img-top" src=<?php echo $row['image'];?>  alt="" height="250px" width="250px"> 
					</div> 
					</div> 
					<h4 class="product-name"><?php echo $row['name'];?></h4> 
					<h4 class="card-title"><?php echo "Price:".$row['price'];?></h4> 
					
					
					<button type="button" class="btn btn-success" name="buy"><a href="odr.php?price=<?php echo $row['price']?> ">BUY</a> </button>
				</div>
			</div> 
			
		
        	<?php
                }
            }
        ?>
    </div> 
 </div> 
</body> 
</html> 


<!--<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<title></title>
</head>
<body>

	<div class="product">
	<div class="container">
		<div class="row">
			<div class="col-md-3">
            <div class="product-item">
	          <div class="product-content">
                <div class="product-img">
    	         <img src="images/bhujia.jpeg" at="Product-Image">
                </div> 
              </div>
  
              <p class="product-name">Bikaneri Bhujia</p> 
    	      <div class="product-btns">
    		          <button type="button" class="btn-cart">Add</button>
    		           <button type="button" class="btn-price">Price:Rs.120</button>
    		 </div> 
    	    </div>
    	</div>
          
         
    		<div class="col-md-3">

	            <div class="product-content">
                    <div class="product-img">
    	            <img src="images/chakri.jpeg" at="Product-Image">
                    </div> 
                </div>
  
                <p class="product-name">Mini Chakri</p> 
    	        <div class="product-btns">
    		          <button type="button" class="btn-cart">Add</button>
    		          <button type="button" class="btn-price">Price:Rs.150</button>
    		    </div> 
    		</div> 
    		
    		
    		<div class="col-md-3">

	            <div class="product-content">
                    <div class="product-img">
    	               <img src="images/a7.jpeg" at="Product-Image">
                    </div> 
                </div>
  
              <p class="product-name">Aashirvaad Atta</p> 
    	        <div class="product-btns">
    		         <button type="button" class="btn-cart">Add</button>
    		         <button type="button" class="btn-price">Price:Rs.260</button>
    		    </div> 
    		</div> 
    	

    		<div class="col-md-3">

	            <div class="product-content">
                    <div class="product-img">
    	                <img src="images/a7.jpeg" at="Product-Image">
                    </div> 
                </div>
  
                <p class="product-name">Aashirvaad Atta</p> 
    	        <div class="product-btns">
    		        <button type="button" class="btn-cart">Add</button>
    		        <button type="button" class="btn-price">Price:Rs.260</button>
    		    </div> 
    		</div> 
    	</div> 
    	<div class="row">
    		<div class="col-md-3">

	            <div class="product-content">
                      <div class="product-img">
    	                    <img src="images/a7.jpeg" at="Product-Image">
                      </div> 
                </div>
  
                <p class="product-name">Aashirvaad Atta</p> 
    	        <div class="product-btns">
    		         <button type="button" class="btn-cart">Add</button>
    		        <button type="button" class="btn-price">Price:Rs.260</button>
    		    </div> 
    		</div> 
    		<div class="col-md-3">

	            <div class="product-content">
                    <div class="product-img">
    	                 <img src="images/a7.jpeg" at="Product-Image">
                    </div> 
                </div>
  
                <p class="product-name">Aashirvaad Atta</p> 
    	        <div class="product-btns">
    		        <button type="button" class="btn-cart">Add</button>
    		        <button type="button" class="btn-price">Price:Rs.260</button>
    		    </div> 
    		</div> 
    	</div> 
    </div> 
    </div> 
</body>
</html>-->