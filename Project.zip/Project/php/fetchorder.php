<?php
$conn=new mysqli("localhost","root"," ","ogs");
$qry="select * from ordr";
$res=$conn->query($qry);
?>
<html>
<head>
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
</head>
<body>
	<div class="container-fluid">
		<div class='row'>
			<div class="col-xl-12">
			<div class="card">
				<div class="card-body">
					<h4 class="box-title">Order</h4>
				</div>
				<div class="card-body">
					<div class="table-stats order-table ov-h">
						<table class="table">
							<thead>
								<tr>
									<th class="serial">#</th>
									<th>Id</th>
								    <th>Customer Name</th>
								    <th>Address</th> 
								    <th>Price</th> 								    
								    <th>Quantity</th> 
								    <th>Total</th>								    
								    </tr>
							</thead>
							<?php
							$i=1;
							while($row=$res->fetch_assoc())
						    {
							?>
							<tr>
								<td><?php echo$i?></td>
								<td><?php echo $row['id']?></td>
								<td><?php echo $row['cname']?></td>
								<td><?php echo $row['address']?></td>
								<td><?php echo $row['price1']?></td>
								<td><?php echo $row['qnty']?></td>
								<td><?php echo $row['total']?></td>
					            <td><span class='btn btn-info'><a href="deleteorder.php?id=<?php echo $row['id'];?>">Delete</a></span> </td>
					             <!--<td><span class='btn btn-danger'><a href="edit.php?id=<?php echo $row['id'];?>">Edit</a></span></td>-->
								</tr>
								<?php 
                            }
                            ?>
					</table>	
				    </div>
		        </div>
	        </div>
            </div>
        </div>
    </div> 
</body> 
</html> 