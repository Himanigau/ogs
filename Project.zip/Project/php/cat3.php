<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<title></title>
</head>
<body>
	<div class="parallax">
		<div class="page-title">Personal Care</div> 
	</div> 
	<div class="container">
		<a href="hair.php">
			<div class="categories">
				<img src="images/31.png" width=30% height=30% class="item-image"/>
				<div class="image-title">Hair Care</div> 
			</div> 
		</a> 
	
		<a href="skin.php">
			<div class="categories">
				<img src="images/28.png" width=30% height=30% class="item-image"/>
				<div class="image-title">Skin Care</div> 
			</div> 
		</a> 
		
		</a> 
		<a href="handwash.php">
			<div class="categories">
				<img src="images/hand-wash.png" width=30% height=30% class="item-image"/>
				<div class="image-title">Handwash</div> 
			</div> 
		</a> 
		</div>
		</body> 
		</html> 