<?php
$id=$_GET['id'];
$conn=new mysqli("localhost","root","","ogs");
$qry="select *from product where id=$id";
$res=$conn->query($qry);
$row=$res->fetch_assoc();
print_r($row);
?>


<html>
<head>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
</head> 
<body>
	<div class="animated fadeIn">
		<div class="container-fluid">
			<div class="row">
				<div class="col=lg-6">

	<div class="card">
		<div class="card-header">
			<h2>AddProduct</h2>
				<div class="block">
					<form method="POST" action="update.php" enctype="multipart/form-data">
						<div class="card-body">
						<div class="form-group">
							<label for="Category" class="form-control-label">Categories</
								label>
						    <select class="form-control" name="categories_id">
							<option value=" Category 1" >Category 1</option>
							<option value="Category 2" >Category 2</option>
							<option value="Category 3" >Category 3</option>
							<option value="Category 4" >Category 4</option>
						    </select>
						    <!--<input type="number" name="categories_id" value=" "placeholder="Enter categories_id" class="form-control">
						</div>-->
					
							<div class="form-group">
						<label for="Product" class="form-control-label">Product</label>
                        <input type="text" name="name" placeholder="Enter product name" class="form-control">
                    </div>
                    <div class="form-group">
						<label for="Price" class="form-control-label">Price</label>
                        <input type="number" name="price" placeholder="Enter price" class="form-control">
                    </div>
                    <div class="form-group">
						<label for="Quantity" class="form-control-label">Quantity</label>
                        <input type="number" name="qty" placeholder="Enter Quantity" class="form-control">
                    </div>
                    <div class="form-group">
						<label for="Image" class="form-control-label">Image</label>
                        <input type="file" name="image" class="form-control">
                    </div>
                    <div class="form-group">
						<label for="Description" class="form-control-label">Description</label>
                        <textarea name="short_description" placeholder="Enter Product short description"  class="form-control"></textarea> 
                    </div>
						 <br>  
			               <div colspan="2" align="center"><input type="submit" name="submit" value="upload" class="btn btn-success"> </div> 
					</div> 
				</div>  
			</form>
			</div>
		</div> 
	</div>
	</div> 
</div>
</div> 
</div> 
</body> 
</html>


<?php
 if(isset($_POST['submit'])){
	print_r($_POST);
	extract($_POST);

     $f=$_FILES['image']['name'];
     $ft=$_FILES['image']['type'];
     $fs=$_FILES['image']['size'];
     print_r($f);
	 $dst="uploading/".$f;
     if (move_uploaded_file($_FILES['image']["tmp_name"],$dst))
     {
     	echo "Files are uploaded.";
     }
                             
							
	
	$conn=new mysqli("localhost","root","","ogs");
	//$qry="insert into product(id,categories_id,name,price,qty.,image,short_description) values(NULL,'$categories_id','$name','$price',qty,'$dst','$short_description')";
	$qry="INSERT INTO `product`(`id`, `categories_id`, `name`, `price`, `qty`, `image`, `short_description`) VALUES (NULL,'$categories_id','$name','$price','$qty','$dst','$short_description')";
	$res=$conn->query($qry);
	if($res)
	{
		echo "Data Saved.";
	}
	else
	{
		echo "Data not Saved";
	}
}
?>