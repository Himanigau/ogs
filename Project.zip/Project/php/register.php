<?php
if(isset($_POST['sub']))
{
    extract($_POST);
     echo "name is:".$name;
     echo $add;
     echo $gender;
     echo $city;
     echo $state;
     echo $pincode;
     echo $mobile;
     echo $email;
     echo "password is:".$password;
     $conn=new mysqli("localhost","root"," ","ogs"); 
    $qry="insert into  register values(NULL,'$name','$add','$gender','$city','$state','$pincode','$mobile','$email','$password')";
    $res=$conn->query($qry);
    if($res)
	{
	     echo "you logged in successfully.";
	     header("location:ogs.php");
   		
	}
	else
	{
         echo "you do not logged in";
	}
}
?>
<html>
<head>
</head>
<body>
<form action="register.php" method="POST">
<table cellpadding="2" width="20%" bgcolor="#FF3366"
cellspacing="2">
<tr>
<td colspan=2>
<center><font size=4><h2>Registration Form</h2></td>
</tr>
<tr>
<td >Name</td>
<td><input type="text" name="name" pattern="[a-zA-Z]{3,}"> </td>
</tr>
<tr>
<td>Address</td>
<td><input type="text"  name="add" pattern="[a-zA-Z0-9}"> </td>
</tr>
<tr>
<td>Gender</td>
<td><input type="radio" name="gender" value="male">Male</td>
<td><input type="radio" name="gender" value="female">Female</td>
</tr>
<tr>
<td>City</td>
<td><input type="text"  name="city" > </td>
</tr>
<tr>
<td>State</td>
<td><select name="state">
<option value="Andhra pradesh">Andhra Pradesh</option>
<option value="Arunachal Pradesh">Arunachal Pradesh</option>
<option value="Assam">Assam</option>
<option value="Bihar">Bihar</option>
<option value="chhatisgarh">Chhastisgarh</option>
<option value="Goa">Goa</option>
<option value="Gujrat">Gujarat</option>
<option value="Haryana">Haryana</option>
<option value="Himachal Pradesh">Himachal Pradesh</option>
<option value="Jharkhand">Jharkhand</option>
<option value="Karnataka">Karnataka</option>
<option value="Kerala">Kerala</option>
<option value="Madhya pradesh">Madhya Pradesh</option>
<option value="Maharashtra">Maharastra</option>
<option value="manipur">Manipur</option>
<option value="Meghalaya">Meghalaya</option>
<option value="mozoram">Mizoram</option>
<option value="Nagaland">Nagaland</option>
<option value="Orissa">Orissa</option>
<option value="Punjab">Punjab</option>
<option value="Rajasthan">Rajasthan</option>
<option value="Sikkim">Sikkim</option>
<option value="Tamil Nadu">Tamil Nadu</option>
<option value="telangana">Telanagana</option>
<option value="Tripura">Tripura</option>
<option value="Uttar pradesh">Uttar pradesh</option>
<option value="West Bengal">West Bengal</option></select></td>
</tr>
<tr>
<td>Pincode</td>
<td><input type="number"  name="pincode" pattern="[0-9]"> </td>
</tr>
<tr>
<td>Mobile No.</td>
<td><input type="text"  name="mobile" pattern="[6-9]{1}[0-9]{9}"> </td>
</tr>
<tr>
<td>Email</td>
<td><input type="text"  name="email" pattern="[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$"> </td>
</tr>
<tr>
<td>Password</td>
<td><input type="password"  name="password" minlength="8"> </td>
</tr>
<tr>
<td><input type="submit" name="sub" value="Submit"></td>
</tr>
</table>
</form>
</body>
</html>