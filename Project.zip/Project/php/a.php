<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style2.css">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/boostrap.min.css">
	<title>Admin panel</title>
</head>
<body >
<div class="wrapper">
	<div class="sidebar">
		<h2>Admin</h2>
		<ul>
			<li><a href="#"></a>Dashboard </li> 
			<li><a href="fetch.php">Customers </a></li> 
			<li><a href="cat.php">Add Category </a></li> 
			<li><a href="product.php">Add Product </a></li>
			<li><a href="contactinsert.php">Contact </a></li> 	
        	<li><a href="fech.php">Category</a></li> 
        	<li><a href="fetch1.php">Product</a></li> 
        	<li><a href="contact.php">Contact Us</a></li>
        	<li><a href="fetchorder.php">Order</a></li> 
        </ul> 
    </div> 
</div>
    <div class="main-content">
    	<div class="header">
    	<br>
    	<br><b>John Doe Admin</b>
    	<br>
    	<br>
    	
    </div> 

    	<div class="info">
        	<div><b>Welcome! Have a nice day</b></div> 
        </div> 
       </div> 

</body>
</html>