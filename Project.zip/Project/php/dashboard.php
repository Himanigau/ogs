<?php
session_start();
if(isset($_SESSION['username']))
{
?>
	<h1>Hello <?php echo$_SESSION["user"];?> </h1> 
	<a href="logout.php">Logout</a> 
	<?php
}
else
{
		header("location:l.php");
}
?>